import { csv } from 'd3';

const csvUrl = 'https://gist.githubusercontent.com/bbbbrianna/7472f5bf8f2bbab14a3e4411cf8869e0/raw/063f25158acbb3054090b59c439a8be5195deb77/calculated_means_sd.csv' 
export const getData = async () => {
  const data = await csv(csvUrl);
  
  // Have a look at the attributes available in the console!
  console.log(data[0]);

  return data;
};