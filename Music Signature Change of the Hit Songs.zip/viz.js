import vl from 'vega-lite-api';
const hover = vl.selectSingle("hover")
    .fields('Type')  // limit selection to x-axis value
    .on('mouseover') // select on mouseover events
    .nearest(true)   // select data point nearest the cursor
    .empty('none')
    .clear("mouseout").init({"Type": "dur"});

const line = vl.markLine()
    .encode(
      vl
      .y()
      .fieldQ('Means')
      .title('Score'),
    vl
      .x()
      .fieldT('Year')
      .scale({ nice: false })
      .title('YEAR'),
    vl
      .color()
      .fieldN("Type").legend(null),
    vl.opacity()
      .if(hover,vl.value(1)).value(0.6),
    vl.strokeWidth().if(hover,vl.value(4)).value(2));
const circle=
      vl.markCircle()
  .encode(
    vl
      .y()
      .fieldQ('Means')
      .title('Score'),
    vl
      .x()
      .fieldT('Year')
      .scale({nice: false })
      .title('YEAR'),
    vl
     .size()
     .fieldQ('SD').title('SD'),
    vl
      .color()
      .fieldN("Type"),
    vl.opacity()
      .if(hover,vl.value(1)).value(0.6)
      .title('Signature'));

const base = line.transform(vl.filter(hover));
const label = {align: 'left', dx: 5, dy: -5};
const white = {stroke: 'white', strokeWidth: 2};

export const viz =
  vl.layer(circle,
    line,
    line.markCircle()
        .select(hover) // use as anchor points for selection
        .encode(vl.opacity().if(hover, vl.value(1)).value(0)),   

    vl.markRule({color: '#aaa'})
        .transform(vl.filter(hover))
        .encode(vl.x().fieldT('date')),
    base.markText(label, white).encode(vl.text().fieldQ('Means')),
    base.markText(label).encode(vl.text().fieldQ('Means')));
