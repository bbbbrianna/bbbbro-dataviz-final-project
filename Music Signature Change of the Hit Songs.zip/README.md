A visualization constructed using the [vega-lite-api](https://github.com/vega/vega-lite-api/).

The graph shows the trend of music component signature since 2010 to 2019. Data were preprocessed by Rstudio, taking the average data of top 10 Spotify playing music every year. Standard deviation is calculated to show the variant of each category.

Hover over a line and it will be bolded and showing the exact average number of each data point.


See Data on Gist: 

[Calculated Mean and SD](https://gist.github.com/bbbbrianna/7472f5bf8f2bbab14a3e4411cf8869e0)

[Yearly Music Trend](https://gist.github.com/bbbbrianna/e74082354cbdfe18d42c7b66ecdefa76)

The original data comes from the 
[Observable](https://observablehq.com/@info474/mood-and-popularity-through-music)