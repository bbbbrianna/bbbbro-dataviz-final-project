An interactive Bar Chart showing the top 15 singer of Spotify from 2010-2019 in U.S. The popularity score in each year of every artist is the sum of all the rank score of their songs. Just simply slide the year to see the change and move the mouse over the bar to see the exact score.

 > |Rule of score computing|||||||||
  | ------ | ------ | ------ | ------ | ------ | ------ | ------ | ------ | ------ |
   | Rank | 1-5 |6-10 | 11-20|21-30 | 31-40 | 41-50|51-60| >60 |
  |Score|15|10|7|5|4|3|2|1|



- Data: [top 15 artist in U.S.](https://gist.github.com/bbbbrianna/d6887ca14cc1924f8ccbd05355226038) 
- Original Data: 
[Yearly Music Trend](https://gist.github.com/bbbbrianna/e74082354cbdfe18d42c7b66ecdefa76)