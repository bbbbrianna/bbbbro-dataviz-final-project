import React, { useState, useCallback, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { csv, arc, pie, scaleBand, scaleLinear, max, format } from 'd3';
import { useData } from './useData';
import { AxisBottom } from './AxisBottom';
import { AxisLeft } from './AxisLeft';
import { Marks } from './Marks';

const width = 960;
const menuHeight = 60;
const height = 500 - menuHeight;
const margin = { top: 20, right: 30, bottom: 65, left: 220 };
const xAxisLabelOffset = 50;
const yAxisLabelOffset = 45;

const Slider = ({ selectedYear, onSelectedYearChange }) => (
  <input
    type="range"
    //list="tickmarks"
    //id="year"
    //name="year"
    min="2010"
    max="2019"
    step="1"
    onChange={(event) => onSelectedYearChange(event.target.value)}
  />
);

const App = () => {
  const data = useData();
  
  const initialYear = '2010';
  const [selectedYear, setSelectedYear] = useState(initialYear);
  const selectedYearValue = (d) => d[selectedYear];
  //console.log(selectedYear)
  if (!data) {
    return <pre>Loading...</pre>;
  }
  

  const selectedYearValues = (d) => d.year;
  const filteredData = data.filter((d) => selectedYear === selectedYearValues(d));
 
  const innerHeight = height - margin.top - margin.bottom;
  const innerWidth = width - margin.left - margin.right;
  
  const yValue = d => d.artist;
  const xValue = d => d.scoring;
  console.log(xValue)

  const siFormat = format('.2n');
  const xAxisTickFormat = tickValue => siFormat(tickValue);
  
  const yScale = scaleBand()
    .domain(filteredData.map(yValue))
    .range([0, innerHeight])
    .paddingInner(0.15);

  const xScale = scaleLinear()
    .domain([0, max(data, xValue)])
    .range([0, innerWidth]);

  return (
    <>
    <div>
      <label className="dropdown-label" for="year">Year</label>
      <Slider
          selectedYear={selectedYear}
          onSelectedYearChange= {setSelectedYear}
        />
     </div> 
    <svg width={width} height={height}>
      <g transform={`translate(${margin.left},${margin.top})`}>
        <AxisBottom
          xScale={xScale}
          innerHeight={innerHeight}
          tickFormat={xAxisTickFormat}
          tickOffset={5}
        />
        <AxisLeft yScale={yScale} />
        <text
          className="axis-label"
          x={innerWidth / 2}
          y={innerHeight + xAxisLabelOffset}
          textAnchor="middle"
        >
          Popularity Score
        </text>
     <text
          className="axis-label"
          x={-50}
          y={innerHeight + xAxisLabelOffset}
          textAnchor="middle"
        >
       {selectedYear}
        </text>
        <Marks
          data={filteredData.slice(0,15)}
          xScale={xScale}
          yScale={yScale}
          xValue={xValue}
          yValue={yValue}
          tooltipFormat={xAxisTickFormat}
        />

      </g>
    </svg>
      </>
  );
};
const rootElement = document.getElementById('root');
ReactDOM.render(<App />, rootElement);