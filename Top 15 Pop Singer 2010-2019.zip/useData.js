import React, { useState, useEffect } from 'react';
import { csv } from 'd3';

const csvUrl =
 'https://gist.githubusercontent.com/bbbbrianna/d6887ca14cc1924f8ccbd05355226038/raw/f656aed0edc256dc3fb05046c8e3c63c815818e7/Scoring_top15_artist.csv'
export const useData = () => {
  const [data, setData] = useState(null);

  useEffect(() => {
    const row = d => {
      d.scoring = +d.scoring;
      return d;
    };
    csv(csvUrl, row).then(setData);
  }, []);
  
  return data;
};