This viz shows the change of top genre of Spotify in the U.S. The top 20 songs of each year from 2010 to 2019 are selected foR this analysis. The slider of Year makes it possible to either focusing on a particular year or comparing over years. The color scale can be selected to show the artist or top genre. X and Y axis can be set to the features of interest. To see a specific Top Genre/Artist, just move mouse on the figure legend to hover one. To know the song of each data point, move your mouse over the point on the scatter plot, it will show the title, artist and top genre of that song.

- [Data Source](https://gist.github.com/bbbbrianna/e74082354cbdfe18d42c7b66ecdefa76)

- [Data Origin](https://observablehq.com/@info474/mood-and-popularity-through-music)
